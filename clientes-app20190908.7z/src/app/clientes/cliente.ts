export class Cliente {
  id: number;
  name: string;
  surname:string;
  createdAt:string;
  birthdate:string;
  email: string;

}
